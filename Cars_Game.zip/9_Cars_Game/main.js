//let set = setInterval(function() {
//    let w = Math.round(Math.random() * (100-20) + 20);
//    let h = Math.round(Math.random() * (100-20) + 20);
//    let top = Math.round(Math.random() * window.innerHeight - 100);
//    let left = Math.round(Math.random() * window.innerWidth - 100);
//    let r = Math.round(Math.random() * 255);
//    let g = Math.round(Math.random() * 255);
//    let b = Math.round(Math.random() * 255);
//    
//    document.write(`<div style="width: ${w}px; height: ${h}px; background: rgb(${r}, ${g}, ${b}); position: absolute; top: ${top}px; left: ${left}px; border-radius: 50%"></div>`)
//}, 400);

/////////////////////////////////////////////////////////////////////////////////////////

const car = document.querySelectorAll('.game .roadFinish .Road .road img:not(.flag)');
const start = document.querySelector('.game .sky .start');
const win = document.querySelectorAll('.game .roadFinish .Road .road .op');
const parentBlock = document.querySelector('.game');
const betWindow = document.querySelector('.game .betWindow');
const radio = document.querySelectorAll('.game .betWindow label input');
const betInput = document.querySelector('.game .betInput');
const money = document.querySelector('.game .score h2');
const skyAnimStop = document.querySelector('.game .sky');

bet.onclick = () => {
    betWindow.classList.toggle('open');
}
minus.onclick = () => {
    if (betInput.value > 199) {
        betInput.value -= 100;
    }
}
plus.onclick = () => {
    betInput.value = +betInput.value + 100;
}

let a = 0,
    b = 0,
    c = 0,
    d = 0;
let r = 0;
let BM = betInput.value;
start.onclick = () => {
        parentBlock.classList.add('STR');
        start.style.display = 'none';
        betWindow.style.display = 'none';
        let game = setInterval(() => {
            let a1 = Math.round(Math.random() * 8);
            let b1 = Math.round(Math.random() * 8);
            let c1 = Math.round(Math.random() * 8);
            let d1 = Math.round(Math.random() * 8);
            a += a1;
            b += b1;
            c += c1;
            d += d1;
            for (let i = 0; i < car.length; i++) {
                console.log(BM);
                car[0].style.marginLeft = a + 'px';
                car[1].style.marginLeft = b + 'px';
                car[2].style.marginLeft = c + 'px';
                car[3].style.marginLeft = d + 'px';
                if (a > window.innerWidth - 140) {
                    r = 1;
                    clearInterval(game);
                    win[0].style.opacity = 1;
                    parentBlock.classList.remove('STR');
                    skyAnimStop.style.animation = 'sky_anim_stop';
                    setTimeout(function () {
                        window.location.reload();
                    }, 3000);
                    break;
                } else if (b > window.innerWidth - 140) {
                    r = 2;
                    clearInterval(game);
                    win[1].style.opacity = 1;
                    parentBlock.classList.remove('STR');
                    skyAnimStop.style.animation = 'sky_anim_stop';
                    setTimeout(function () {
                        window.location.reload();
                    }, 3000);
                    break;
                } else if (c > window.innerWidth - 140) {
                    r = 3;
                    clearInterval(game);
                    win[2].style.opacity = 1;
                    parentBlock.classList.remove('STR');
                    skyAnimStop.style.animation = 'sky_anim_stop';
                    setTimeout(function () {
                        window.location.reload();
                    }, 3000);
                    break;
                } else if (d > window.innerWidth - 140) {
                    r = 4;
                    clearInterval(game);
                    win[3].style.opacity = 1;
                    parentBlock.classList.remove('STR');
                    skyAnimStop.style.animation = 'sky_anim_stop';
                    setTimeout(function () {
                        window.location.reload();
                    }, 3000);
                    break;
                }
            }
        }, 5);
};
